const products = [
    {
        title: 'product1',
        endDate: '2017-07-02T08:30:00'
    },
    {
        title: 'product2',
        endDate: '2017-07-04T10:20:00'
    },
    {
        title: 'product3',
        endDate: '2017-07-10T12:45:00'
    },
]

export function getProducts() {
    return products
}