<template>
    <div class="container">
        <b>Start: </b>
        <gmap-autocomplete @place_changed="setWaypoint"></gmap-autocomplete>
        <b>End: </b>
        <gmap-autocomplete @place_changed="setWaypoint"></gmap-autocomplete>
        <gmap-map
                ref="map"
                :center="center"
                :zoom="10"
                style="width: 100%; height: 500px"
        >
        </gmap-map>
    </div>
</template>

<script>
    export default {
        data () {
            return {
                center: {lat: 10.0, lng: 10.0},
                start: '',
                end: ''
            }
        },
        mounted() {
            setTimeout(() => {
                this.direction()
            }, 1000)
        },
        methods: {
            direction() {
                let directionsService = new google.maps.DirectionsService
                let directionsDisplay = new google.maps.DirectionsRenderer

                directionsDisplay.setMap(this.$refs.map.$mapObject)

                var onChangeHandler = function() {
                    calculateAndDisplayRoute(directionsService, directionsDisplay)
                }

                function calculateAndDisplayRoute(directionsService, directionsDisplay) {
                    directionsService.route({
                        origin: document.getElementById('start').value,
                        destination: document.getElementById('end').value,
                        travelMode: 'DRIVING'
                    }, function(response, status) {
                        if (status === 'OK') {
                            console.log(response)
                            directionsDisplay.setDirections(response)
                        } else {
                            window.alert('Directions request failed due to ' + status)
                        }
                    });
                }
            },
            setWaypoint(event) {
                console.log(event)
            }
        }
    }
</script>